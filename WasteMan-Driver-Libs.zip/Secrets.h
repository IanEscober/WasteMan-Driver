//Contains user secrets and other sensitive data

struct Secrets {
    const char* APN = "Your Network Provider's APN";
    const char* BROKER_HOST= "Your Broker Host";
    const int BROKER_PORT= "Your Broker Port";
    const char* BROKER_USERNAME= "Your Broker Username";
    const char* BROKER_PASSWORD= "Your Broker Password";
};